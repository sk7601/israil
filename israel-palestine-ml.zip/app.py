# Streamlit App: Israel-Palestine Conflict Analysis
# Author: Sumit Kaushik | Roll No: 23/MC/201
# (Streamlit code is loaded from canvas, so we're reusing it here.)
