# 🇮🇱 Israel-Palestine Conflict Analysis using Machine Learning

This Streamlit app provides an interactive interface to:
- 📈 Visualize conflict trends over time using ACLED data
- 🤖 Predict high-fatality events using machine learning
- 🐦 Analyze public sentiment via tweets using VADER sentiment analysis

## 🚀 Features
- Upload ACLED conflict CSV dataset
- Random Forest model to classify high-fatality events
- Real-time Twitter sentiment analysis using `snscrape`
- WordCloud and sentiment distribution graphs

## 🔧 Installation

```bash
git clone https://github.com/your-username/israel-palestine-ml.git
cd israel-palestine-ml
pip install -r requirements.txt
streamlit run app.py
```

## 📁 File Structure
```bash
.
├── app.py                 # Streamlit application
├── requirements.txt       # Required Python libraries
└── README.md              # Project documentation
```

## 📡 Data Source
- Conflict data from [ACLED](https://acleddata.com/)
- Tweets scraped using `snscrape` (open-source)

---

**Author**: Sumit Kaushik  
**Roll No**: 23/MC/201  
